﻿namespace W4_TakeHome
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.labelTeamName = new System.Windows.Forms.Label();
            this.labelCountryName = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.labelAddingTeam = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.labelPNum = new System.Windows.Forms.Label();
            this.labelPos = new System.Windows.Forms.Label();
            this.labelAddingPlayer = new System.Windows.Forms.Label();
            this.textBoxPlayerName = new System.Windows.Forms.TextBox();
            this.textBoxTeamName = new System.Windows.Forms.TextBox();
            this.textBoxTeamCountry = new System.Windows.Forms.TextBox();
            this.textBoxPlayerNumber = new System.Windows.Forms.TextBox();
            this.textBoxTeamCity = new System.Windows.Forms.TextBox();
            this.comboBoxPlayerPos = new System.Windows.Forms.ComboBox();
            this.buttonAddTeam = new System.Windows.Forms.Button();
            this.buttonAddPlayer = new System.Windows.Forms.Button();
            this.labelSoccerTeam = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.comboBoxCountry = new System.Windows.Forms.ComboBox();
            this.comboBoxTeam = new System.Windows.Forms.ComboBox();
            this.listBoxOutput = new System.Windows.Forms.ListBox();
            this.buttonRemove = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // labelTeamName
            // 
            this.labelTeamName.AutoSize = true;
            this.labelTeamName.Location = new System.Drawing.Point(288, 80);
            this.labelTeamName.Name = "labelTeamName";
            this.labelTeamName.Size = new System.Drawing.Size(89, 16);
            this.labelTeamName.TabIndex = 0;
            this.labelTeamName.Text = "Team Name :";
            // 
            // labelCountryName
            // 
            this.labelCountryName.AutoSize = true;
            this.labelCountryName.Location = new System.Drawing.Point(288, 107);
            this.labelCountryName.Name = "labelCountryName";
            this.labelCountryName.Size = new System.Drawing.Size(97, 16);
            this.labelCountryName.TabIndex = 1;
            this.labelCountryName.Text = "Team Country :";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(288, 137);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(74, 16);
            this.label1.TabIndex = 2;
            this.label1.Text = "Team City :";
            // 
            // labelAddingTeam
            // 
            this.labelAddingTeam.AutoSize = true;
            this.labelAddingTeam.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelAddingTeam.Location = new System.Drawing.Point(380, 50);
            this.labelAddingTeam.Name = "labelAddingTeam";
            this.labelAddingTeam.Size = new System.Drawing.Size(89, 16);
            this.labelAddingTeam.TabIndex = 3;
            this.labelAddingTeam.Text = "Adding Team";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(518, 75);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(92, 16);
            this.label2.TabIndex = 4;
            this.label2.Text = "Player Name :";
            // 
            // labelPNum
            // 
            this.labelPNum.AutoSize = true;
            this.labelPNum.Location = new System.Drawing.Point(518, 107);
            this.labelPNum.Name = "labelPNum";
            this.labelPNum.Size = new System.Drawing.Size(103, 16);
            this.labelPNum.TabIndex = 5;
            this.labelPNum.Text = "Player Number :";
            // 
            // labelPos
            // 
            this.labelPos.AutoSize = true;
            this.labelPos.Location = new System.Drawing.Point(518, 135);
            this.labelPos.Name = "labelPos";
            this.labelPos.Size = new System.Drawing.Size(103, 16);
            this.labelPos.TabIndex = 6;
            this.labelPos.Text = "Player Position :";
            // 
            // labelAddingPlayer
            // 
            this.labelAddingPlayer.AutoSize = true;
            this.labelAddingPlayer.Location = new System.Drawing.Point(624, 50);
            this.labelAddingPlayer.Name = "labelAddingPlayer";
            this.labelAddingPlayer.Size = new System.Drawing.Size(99, 16);
            this.labelAddingPlayer.TabIndex = 7;
            this.labelAddingPlayer.Text = "Adding Players";
            // 
            // textBoxPlayerName
            // 
            this.textBoxPlayerName.Location = new System.Drawing.Point(627, 74);
            this.textBoxPlayerName.Name = "textBoxPlayerName";
            this.textBoxPlayerName.Size = new System.Drawing.Size(121, 22);
            this.textBoxPlayerName.TabIndex = 8;
            // 
            // textBoxTeamName
            // 
            this.textBoxTeamName.Location = new System.Drawing.Point(383, 75);
            this.textBoxTeamName.Name = "textBoxTeamName";
            this.textBoxTeamName.Size = new System.Drawing.Size(100, 22);
            this.textBoxTeamName.TabIndex = 9;
            // 
            // textBoxTeamCountry
            // 
            this.textBoxTeamCountry.Location = new System.Drawing.Point(383, 107);
            this.textBoxTeamCountry.Name = "textBoxTeamCountry";
            this.textBoxTeamCountry.Size = new System.Drawing.Size(100, 22);
            this.textBoxTeamCountry.TabIndex = 10;
            // 
            // textBoxPlayerNumber
            // 
            this.textBoxPlayerNumber.Location = new System.Drawing.Point(627, 108);
            this.textBoxPlayerNumber.Name = "textBoxPlayerNumber";
            this.textBoxPlayerNumber.Size = new System.Drawing.Size(121, 22);
            this.textBoxPlayerNumber.TabIndex = 11;
            // 
            // textBoxTeamCity
            // 
            this.textBoxTeamCity.Location = new System.Drawing.Point(383, 137);
            this.textBoxTeamCity.Name = "textBoxTeamCity";
            this.textBoxTeamCity.Size = new System.Drawing.Size(100, 22);
            this.textBoxTeamCity.TabIndex = 12;
            // 
            // comboBoxPlayerPos
            // 
            this.comboBoxPlayerPos.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxPlayerPos.FormattingEnabled = true;
            this.comboBoxPlayerPos.Items.AddRange(new object[] {
            "GK",
            "DF",
            "MF",
            "FW"});
            this.comboBoxPlayerPos.Location = new System.Drawing.Point(627, 132);
            this.comboBoxPlayerPos.Name = "comboBoxPlayerPos";
            this.comboBoxPlayerPos.Size = new System.Drawing.Size(121, 24);
            this.comboBoxPlayerPos.TabIndex = 13;
            // 
            // buttonAddTeam
            // 
            this.buttonAddTeam.Location = new System.Drawing.Point(383, 162);
            this.buttonAddTeam.Name = "buttonAddTeam";
            this.buttonAddTeam.Size = new System.Drawing.Size(75, 23);
            this.buttonAddTeam.TabIndex = 14;
            this.buttonAddTeam.Text = "Add";
            this.buttonAddTeam.UseVisualStyleBackColor = true;
            this.buttonAddTeam.Click += new System.EventHandler(this.buttonAddTeam_Click);
            // 
            // buttonAddPlayer
            // 
            this.buttonAddPlayer.Location = new System.Drawing.Point(627, 162);
            this.buttonAddPlayer.Name = "buttonAddPlayer";
            this.buttonAddPlayer.Size = new System.Drawing.Size(75, 23);
            this.buttonAddPlayer.TabIndex = 15;
            this.buttonAddPlayer.Text = "Add";
            this.buttonAddPlayer.UseVisualStyleBackColor = true;
            this.buttonAddPlayer.Click += new System.EventHandler(this.buttonAddPlayer_Click);
            // 
            // labelSoccerTeam
            // 
            this.labelSoccerTeam.AutoSize = true;
            this.labelSoccerTeam.Font = new System.Drawing.Font("Microsoft Sans Serif", 19.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelSoccerTeam.Location = new System.Drawing.Point(12, 9);
            this.labelSoccerTeam.Name = "labelSoccerTeam";
            this.labelSoccerTeam.Size = new System.Drawing.Size(288, 38);
            this.labelSoccerTeam.TabIndex = 16;
            this.labelSoccerTeam.Text = "Soccer Team List";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(12, 80);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(108, 16);
            this.label3.TabIndex = 17;
            this.label3.Text = "Choose Country :";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(12, 110);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(99, 16);
            this.label4.TabIndex = 18;
            this.label4.Text = "Choose Team :";
            // 
            // comboBoxCountry
            // 
            this.comboBoxCountry.FormattingEnabled = true;
            this.comboBoxCountry.Location = new System.Drawing.Point(122, 75);
            this.comboBoxCountry.Name = "comboBoxCountry";
            this.comboBoxCountry.Size = new System.Drawing.Size(121, 24);
            this.comboBoxCountry.TabIndex = 19;
            this.comboBoxCountry.SelectedIndexChanged += new System.EventHandler(this.comboBoxCountry_SelectedIndexChanged);
            // 
            // comboBoxTeam
            // 
            this.comboBoxTeam.FormattingEnabled = true;
            this.comboBoxTeam.Location = new System.Drawing.Point(122, 108);
            this.comboBoxTeam.Name = "comboBoxTeam";
            this.comboBoxTeam.Size = new System.Drawing.Size(121, 24);
            this.comboBoxTeam.TabIndex = 20;
            this.comboBoxTeam.SelectedIndexChanged += new System.EventHandler(this.comboBoxTeam_SelectedIndexChanged);
            // 
            // listBoxOutput
            // 
            this.listBoxOutput.FormattingEnabled = true;
            this.listBoxOutput.ItemHeight = 16;
            this.listBoxOutput.Location = new System.Drawing.Point(15, 178);
            this.listBoxOutput.Name = "listBoxOutput";
            this.listBoxOutput.Size = new System.Drawing.Size(263, 164);
            this.listBoxOutput.TabIndex = 21;
            // 
            // buttonRemove
            // 
            this.buttonRemove.Location = new System.Drawing.Point(203, 348);
            this.buttonRemove.Name = "buttonRemove";
            this.buttonRemove.Size = new System.Drawing.Size(75, 23);
            this.buttonRemove.TabIndex = 22;
            this.buttonRemove.Text = "Remove";
            this.buttonRemove.UseVisualStyleBackColor = true;
            this.buttonRemove.Click += new System.EventHandler(this.buttonRemove_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Control;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.buttonRemove);
            this.Controls.Add(this.listBoxOutput);
            this.Controls.Add(this.comboBoxTeam);
            this.Controls.Add(this.comboBoxCountry);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.labelSoccerTeam);
            this.Controls.Add(this.buttonAddPlayer);
            this.Controls.Add(this.buttonAddTeam);
            this.Controls.Add(this.comboBoxPlayerPos);
            this.Controls.Add(this.textBoxTeamCity);
            this.Controls.Add(this.textBoxPlayerNumber);
            this.Controls.Add(this.textBoxTeamCountry);
            this.Controls.Add(this.textBoxTeamName);
            this.Controls.Add(this.textBoxPlayerName);
            this.Controls.Add(this.labelAddingPlayer);
            this.Controls.Add(this.labelPos);
            this.Controls.Add(this.labelPNum);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.labelAddingTeam);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.labelCountryName);
            this.Controls.Add(this.labelTeamName);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label labelTeamName;
        private System.Windows.Forms.Label labelCountryName;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label labelAddingTeam;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label labelPNum;
        private System.Windows.Forms.Label labelPos;
        private System.Windows.Forms.Label labelAddingPlayer;
        private System.Windows.Forms.TextBox textBoxPlayerName;
        private System.Windows.Forms.TextBox textBoxTeamName;
        private System.Windows.Forms.TextBox textBoxTeamCountry;
        private System.Windows.Forms.TextBox textBoxPlayerNumber;
        private System.Windows.Forms.TextBox textBoxTeamCity;
        private System.Windows.Forms.ComboBox comboBoxPlayerPos;
        private System.Windows.Forms.Button buttonAddTeam;
        private System.Windows.Forms.Button buttonAddPlayer;
        private System.Windows.Forms.Label labelSoccerTeam;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.ComboBox comboBoxCountry;
        private System.Windows.Forms.ComboBox comboBoxTeam;
        private System.Windows.Forms.ListBox listBoxOutput;
        private System.Windows.Forms.Button buttonRemove;
    }
}

