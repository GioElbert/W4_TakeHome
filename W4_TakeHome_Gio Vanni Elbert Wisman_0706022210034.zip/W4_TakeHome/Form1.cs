﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace W4_TakeHome
{
    public partial class Form1 : Form
    {

       List<Team> teamList = new List<Team>();
       



        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            List<Player> playerList = new List<Player>();
            Player player1 = new Player( "01 " ,"David De Gea ", "GK ");
            playerList.Add(player1);
            Player player2 = new Player( "02 ", "Victor Lindelof" , "Df ");
            playerList.Add(player2);
            Player player3 = new Player("04", "Phil Jones", "DF");
            playerList.Add(player3);
            Player player4 = new Player("05", "Harry Maguire", "DF");
            playerList.Add(player4);
            Player player5 = new Player("06", "Lisandro Martinez", "DF");
            playerList.Add(player5);
            Player player6 = new Player("08", "Bruno Fernandes", "MF");
            playerList.Add(player6);
            Player player7 = new Player("09", "Anthony Martial", "FW");
            playerList.Add(player7);
            Player player8 = new Player("10", "Marcus Rashford", "FW");
            playerList.Add(player8);
            Player player9 = new Player("12", "Tyrell Malacia", "DF");
            playerList.Add(player9);
            Player player10 = new Player("14", "Christian Eriksen", "MF");
            playerList.Add(player10);
            Player player11 = new Player("18", "Casemiro", "MF");
            playerList.Add(player11);



           
            Team MU = new Team (playerList, "Manchester United" , "England " , "Manchester ");
            teamList.Add(MU);


            List<Player> playerList1 = new List<Player>();

            Player playera = new Player("01", "Kepa Arrizabalaga", "GK");
            playerList1.Add(playera);
            Player playerb = new Player("04", "Benoit Badiashile", "DF");
            playerList1.Add(playerb);
            Player playerc = new Player("05", "Enzo Fernandez", "MF");
            playerList1.Add(playerc);
            Player playerd = new Player("06", "Thiago Silva", "DF");
            playerList1.Add(playerd);
            Player playere = new Player("07", "N Golo Kante", "MF");
            playerList1.Add(playere);
            Player playerf = new Player("08", "Mateo Kovacic", "MK");
            playerList1.Add(playerf);
            Player playerg = new Player("09", "Pierre-Emerick Aubameyang", "GK");
            playerList1.Add(playerg);
            Player playerh = new Player("10", "Christian Pulisic", "MF");
            playerList1.Add(playerh);
            Player playeri = new Player("11", "Joao Felix", "FW");
            playerList1.Add(playeri);
            Player playerj = new Player("12", "Ruben Loftus-Cheek", "MF");
            playerList1.Add(playerj);
            Player playerk = new Player("17", "Raheem Sterling", "MF");
            playerList1.Add(playerk);

            Team Chelsea = new Team(playerList1, "Chelsea", "England ", "London ");
            teamList.Add(Chelsea);

            List<Player> playerList2 = new List<Player>();
            Player playerl = new Player("01", "Manuel Neuer", "GK");
            playerList2.Add(playerl);
            Player playerm = new Player("02", "Dayot Upamecano", "DF");
            playerList2.Add(playerm);
            Player playern = new Player("04", "Matthijs de Ligt", "DF");
            playerList2.Add(playern);
            Player playero = new Player("05", "Benjamin Pavard", "DF");
            playerList2.Add(playero);
            Player playerp = new Player("06", "Joshua Kimmich", "MF");
            playerList2.Add(playerp);
            Player playerq = new Player("07", "Serge Gnarby", "FW");
            playerList2.Add(playerq);
            Player playerr = new Player("08", "Leon Goretzka", "MF");
            playerList2.Add(playerr);
            Player players = new Player("10", "Leroy Sane", "FW");
            playerList2.Add(players);
            Player playert = new Player("14", "Paul Wanner", "MF");
            playerList2.Add(playert);
            Player playeru = new Player("21", "Lucas Hernandez", "DF");
            playerList2.Add(playeru);
            Player playerv = new Player("25", "Thomas Muller", "FW");
            playerList2.Add(playerv);

            Team Bayern = new Team(playerList2, "Bayern Munich", "Germany ", "Munich ");
            teamList.Add(Bayern);

            foreach (var team in teamList)
            {


                if (!comboBoxCountry.Items.Contains(team.getnamaCountry()))
                {
                    comboBoxCountry.Items.Add(team.getnamaCountry());
                }

            }
        }

        private void comboBoxCountry_SelectedIndexChanged(object sender, EventArgs e)
        {
            comboBoxTeam.Items.Clear();
            foreach (var team in teamList)

            {
               
                if (team.getnamaCountry() == comboBoxCountry.Text)

                {
                    
                    comboBoxTeam.Items.Add(team.getnamaTeam());
                }
                      
            }
        }

        private void comboBoxTeam_SelectedIndexChanged(object sender, EventArgs e)
        {
            listBoxOutput.Items.Clear();
            foreach (var team in teamList)
            {
                
                if (team.getnamaTeam() == comboBoxTeam.Text) 
                {
                    
                    foreach (var player in team.viewAllplayer())
                    {


                        listBoxOutput.Items.Add("(" + player.getNumberPlayer() + ") " + player.getPlayerName() + ", " + player.getposisiPlayer());

                    }
                }
            }

            

        }

        private void buttonRemove_Click(object sender, EventArgs e)
        {
            if (listBoxOutput.Items.Count > 11)
            {



                if (listBoxOutput.SelectedItem != null)
                {
                    foreach (var team in teamList)
                    {
                        if (comboBoxTeam.Text == team.getnamaTeam())
                        {
                            team.removePlayer(listBoxOutput.SelectedIndex);
                        }
                    }
                    listBoxOutput.Items.Remove(listBoxOutput.SelectedItem);
                }
            }
            else
            {
                MessageBox.Show("Player Number Cannot Less Then 11");
            }
        }

        private void buttonAddTeam_Click(object sender, EventArgs e)
        {
            double value;

            if ((!double.TryParse(textBoxTeamName.Text, out value)) && (!double.TryParse(textBoxTeamCountry.Text, out value)) && (!double.TryParse(textBoxTeamCity.Text, out value)))
            {
                bool uniq = true;
                foreach (var team in teamList)
                {
                    if (team.getnamaTeam() == textBoxTeamName.Text)
                    {
                        uniq = false;
                    }
                }
                if (uniq)
                {


                    List<Player> list = new List<Player>();
                    Team TeamBaru = new Team(list, textBoxTeamName.Text, textBoxTeamCountry.Text, textBoxTeamCity.Text);
                    teamList.Add(TeamBaru);
                    foreach (var team in teamList)
                    {


                        if (!comboBoxCountry.Items.Contains(team.getnamaCountry()))
                        {
                            comboBoxCountry.Items.Add(team.getnamaCountry());
                        }


                    }
                    textBoxTeamName.Clear();
                    textBoxTeamCountry.Clear();
                    textBoxTeamCity.Clear();
                }

                else
                {
                    MessageBox.Show("The team was already added before !!");
                }
            }
            else
            {
                
                MessageBox.Show("Please enter a valid data");
            }
            
        }

        private void buttonAddPlayer_Click(object sender, EventArgs e)
        {
            double value;

            if ((!double.TryParse(textBoxPlayerName.Text, out value)) && (double.TryParse(textBoxPlayerNumber.Text, out value)))
            {
                
                foreach (var team in teamList)
                {
                    if (comboBoxTeam.Text == team.getnamaTeam())
                    {
                        Player pemainBaru = new Player(textBoxPlayerNumber.Text, textBoxPlayerName.Text, comboBoxPlayerPos.Text);
                        team.addPlayer(pemainBaru);
                        listBoxOutput.Items.Clear();


                        if (team.getnamaTeam() == comboBoxTeam.Text)
                        {

                            foreach (var player in team.viewAllplayer())
                            {


                                listBoxOutput.Items.Add("(" + player.getNumberPlayer() + ") " + player.getPlayerName() + ", " + player.getposisiPlayer());

                            }
                        }

                        textBoxPlayerNumber.Clear();
                        textBoxPlayerName.Clear();
                        comboBoxPlayerPos.Text = " ";



                    }
                }
            }
            else
            {
               
                MessageBox.Show("Please enter a valid Data.");
            }

            
        }
    }
}
