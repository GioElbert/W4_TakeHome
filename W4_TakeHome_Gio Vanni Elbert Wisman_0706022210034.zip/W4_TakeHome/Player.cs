﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace W4_TakeHome
{
    internal class Player
    {
        private string namaPlayer;
        private string numberPlayer;
        private string posisiPlayer;

        public Player(string numberPlayer , string namaPlayer , string posisiPlayer)
        {
            
            this.namaPlayer = namaPlayer;
            this.numberPlayer = numberPlayer;
            this.posisiPlayer = posisiPlayer;
        }

        public string getPlayerName()
        { 
            return namaPlayer;
        }

        public void setPlayerName(string nama)
        {
            this.namaPlayer = nama;

        }


        public string getNumberPlayer() 
        { 
            return numberPlayer;
        }

        public void setNumberPlayer(string number)
        { 
            numberPlayer = number; 
        }   
        public string getposisiPlayer()
        { 
            return posisiPlayer;
        }

        public void setposisiPlayer(string posisi)
        {
            this.posisiPlayer = posisi;
        }



    }
}
