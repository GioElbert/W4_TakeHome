﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace W4_TakeHome
{
    internal class Team
    {
        private List <Player> listplayers = new List <Player> ();

        private string namaTeam;
        private string namaCountry;
        private string namaCity;

        public Team(List <Player> listplayer , string namaTeam , string namaCountry , string namaCity)
        {
            this.namaTeam = namaTeam;
            this.namaCountry = namaCountry;
            this.namaCity = namaCity;
            this.listplayers = listplayer;
        }

        public List <Player> viewAllplayer()
        {
            return this.listplayers;
            
        }

        public void addPlayer(Player pemainBaru)
        {
            this.listplayers.Add(pemainBaru);
        }

        public void removePlayer(int playerId)
        {
            this.listplayers.RemoveAt(playerId);
        }

        public string getnamaTeam ()
        {
            return this.namaTeam;
        }
        public void setnamaTeam(string namatim)
        {
           this.namaTeam = namatim;
        }   
        public string getnamaCountry()
        {
            return namaCountry;
        }

        public void setnamaCountry(string namacountry)
        {
            this.namaCountry=namacountry;
        }

        public string getnamaCity() 
        { 
            return namaCity; 
        }    

        public void setnamaCity(string namaCity)
        {
            this.namaCity = namaCity;
        }
    }
}
